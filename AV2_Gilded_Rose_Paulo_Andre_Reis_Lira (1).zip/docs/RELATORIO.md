# Relatório técnico

O código legado concentrava as regras de todos os itens em `att()`, com condicionais aninhadas, duplicação, strings mágicas e responsabilidades misturadas.

A refatoração preservou a interface pública principal e delegou a atualização para regras específicas: Normal, Aged Brie, Sulfuras, Backstage e Conjured. Isso reduz a complexidade do método `att()` e aplica SRP. O mapa de regras permite adicionar um novo tipo sem ampliar uma cadeia de `if/elif`, apoiando OCP.

Os limites de qualidade foram centralizados e os testes cobrem comportamento antes/depois do vencimento e limites de qualidade. O Conjured foi implementado como nova regra, degradando duas vezes mais rápido que o item normal.
