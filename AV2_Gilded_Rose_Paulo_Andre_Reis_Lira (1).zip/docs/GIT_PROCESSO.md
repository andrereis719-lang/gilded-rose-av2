# Processo Git

Mensagens convencionais sugeridas para o histórico real:

- `chore: adiciona codigo legado do Gilded Rose`
- `test: adiciona testes de caracterizacao do legado`
- `refactor: separa regras de atualizacao por tipo`
- `feat: adiciona regra do Conjured Mana Cake`
- `test: adiciona testes do Conjured`
- `docs: atualiza README e relatorio`

Não devem ser criados commits, colaboradores ou revisões fictícias.
