# AV2 - Refatoração do Gilded Rose

Projeto desenvolvido a partir do `gilded_rose.py` legado fornecido na AV2.

## Refatoração

- Mantida a classe `Item` e a interface `GildedRose.att()` do legado.
- Removida a função gigante: cada tipo possui uma regra própria.
- Substituídos nomes/strings mágicas por constantes e nomes expressivos.
- Centralizados os limites de qualidade (`0` e `50`).
- Aplicados SRP, DRY, KISS e OCP por meio das classes de regras.
- O código continua aceitando itens desconhecidos como itens normais.

## Conjured Mana Cake

- perde 2 de qualidade por dia antes do vencimento;
- perde 4 por dia após o vencimento;
- nunca fica abaixo de 0.

## Testes

Instale `pytest` e execute:

```bash
pytest -q
```

Os testes cobrem Normal, Aged Brie, Sulfuras, Backstage e Conjured, incluindo vencimento e limites.

## Processo Git

O enunciado solicita branches, commits convencionais, Pull Requests e revisão cruzada. O histórico deste repositório deve conter apenas ações realmente realizadas; não devem ser inventados colaboradores ou revisões.
