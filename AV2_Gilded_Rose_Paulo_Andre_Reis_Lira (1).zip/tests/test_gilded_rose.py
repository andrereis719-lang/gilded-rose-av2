from gilded_rose import Item, GildedRose


def update(item):
    GildedRose([item]).att()
    return item


def test_normal_before_expiry():
    item = update(Item("Elixir of the Mongoose", 5, 10))
    assert (item.sell_in, item.quality) == (4, 9)


def test_normal_after_expiry():
    item = update(Item("Elixir of the Mongoose", -1, 10))
    assert (item.sell_in, item.quality) == (-2, 8)


def test_normal_never_below_zero():
    assert update(Item("normal", 5, 0)).quality == 0


def test_aged_brie_before_expiry():
    item = update(Item("Aged Brie", 5, 10))
    assert (item.sell_in, item.quality) == (4, 11)


def test_aged_brie_after_expiry():
    item = update(Item("Aged Brie", -1, 10))
    assert (item.sell_in, item.quality) == (-2, 12)


def test_aged_brie_max_50():
    assert update(Item("Aged Brie", 5, 50)).quality == 50


def test_sulfuras_never_changes():
    item = update(Item("Sulfuras, Hand of Ragnaros", 10, 80))
    assert (item.sell_in, item.quality) == (10, 80)


def test_backstage_more_than_ten_days():
    item = update(Item("Backstage passes to a TAFKAL80ETC concert", 15, 10))
    assert (item.sell_in, item.quality) == (14, 11)


def test_backstage_between_six_and_ten_days():
    item = update(Item("Backstage passes to a TAFKAL80ETC concert", 10, 10))
    assert (item.sell_in, item.quality) == (9, 12)


def test_backstage_between_one_and_five_days():
    item = update(Item("Backstage passes to a TAFKAL80ETC concert", 5, 10))
    assert (item.sell_in, item.quality) == (4, 13)


def test_backstage_after_show():
    item = update(Item("Backstage passes to a TAFKAL80ETC concert", -1, 40))
    assert (item.sell_in, item.quality) == (-2, 0)


def test_backstage_max_50():
    assert update(Item("Backstage passes to a TAFKAL80ETC concert", 5, 50)).quality == 50


def test_conjured_before_expiry():
    item = update(Item("Conjured Mana Cake", 5, 10))
    assert (item.sell_in, item.quality) == (4, 8)


def test_conjured_after_expiry():
    item = update(Item("Conjured Mana Cake", -1, 10))
    assert (item.sell_in, item.quality) == (-2, 6)


def test_conjured_never_below_zero():
    assert update(Item("Conjured Mana Cake", 2, 1)).quality == 0
