"""Gilded Rose - código legado refatorado."""

MAX_QUALITY = 50
MIN_QUALITY = 0
AGED_BRIE = "Aged Brie"
SULFURAS = "Sulfuras, Hand of Ragnaros"
BACKSTAGE = "Backstage passes to a TAFKAL80ETC concert"
CONJURED = "Conjured Mana Cake"


class Item:
    """Representa um item do inventário."""

    def __init__(self, name, sell_in, quality):
        self.name = name
        self.sell_in = sell_in
        self.quality = quality

    def __repr__(self):
        return "%s, %s, %s" % (self.name, self.sell_in, self.quality)


class ItemRule:
    """Interface das regras de atualização."""

    def update(self, item):
        raise NotImplementedError


class NormalItemRule(ItemRule):
    """Regra dos itens normais."""

    def update(self, item):
        loss = 2 if item.sell_in < 0 else 1
        item.quality = max(MIN_QUALITY, item.quality - loss)
        item.sell_in -= 1


class AgedBrieRule(ItemRule):
    """Regra do Aged Brie."""

    def update(self, item):
        gain = 2 if item.sell_in < 0 else 1
        item.quality = min(MAX_QUALITY, item.quality + gain)
        item.sell_in -= 1


class SulfurasRule(ItemRule):
    """Sulfuras não altera sell_in nem quality."""

    def update(self, item):
        return


class BackstageRule(ItemRule):
    """Regra dos ingressos Backstage."""

    def update(self, item):
        if item.sell_in < 0:
            item.quality = MIN_QUALITY
            item.sell_in -= 1
            return

        gain = 1
        if item.sell_in < 11:
            gain += 1
        if item.sell_in < 6:
            gain += 1

        item.quality = min(MAX_QUALITY, item.quality + gain)
        item.sell_in -= 1


class ConjuredManaCakeRule(ItemRule):
    """Conjured perde qualidade duas vezes mais rápido que o normal."""

    def update(self, item):
        loss = 4 if item.sell_in < 0 else 2
        item.quality = max(MIN_QUALITY, item.quality - loss)
        item.sell_in -= 1


class GildedRose:
    """Atualiza os itens delegando cada regra à sua responsabilidade."""

    def __init__(self, items):
        self.items = items
        self.rules = {
            AGED_BRIE: AgedBrieRule(),
            SULFURAS: SulfurasRule(),
            BACKSTAGE: BackstageRule(),
            CONJURED: ConjuredManaCakeRule(),
        }
        self.default_rule = NormalItemRule()

    def _rule_for(self, item):
        """Retorna a regra específica ou a regra normal."""
        return self.rules.get(item.name, self.default_rule)

    def att(self):
        """Atualiza todos os itens por um dia; nome preservado do legado."""
        for item in self.items:
            self._rule_for(item).update(item)
